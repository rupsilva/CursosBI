# Microsoft Power BI Para Data Science

Seja Bem-vindo ao Repositório do curso Microsoft Power BI Para Data Science. Aqui você encontra todos os scripts, manuais, e-books e datasets usados no curso, bem como os exercícios.

https://www.datascienceacademy.com.br

